package com.desafio_01.desconto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DescontoApplicationTests {

	@Test
	void contextLoads() {
	}

}
