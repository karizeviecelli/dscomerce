package com.desafio_01.desconto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DescontoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DescontoApplication.class, args);
	}

}
