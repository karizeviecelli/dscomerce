# Loja de Aviamentos & Tintas — Etapa 1 (Usuário & Login)

Projeto educacional (SA SENAI) com **Spring Boot 3**, **Spring Security**, **JPA/Hibernate**, **H2**, **Thymeleaf** e **Bootstrap**.

## Objetivo desta etapa
- Cadastro de usuário com validação e **hash BCrypt**.
- Autenticação por formulário e sessão.
- Telas responsivas (login/registro + home).

## Executar
```bash
mvn spring-boot:run
```

Acesse:
- Login: `http://localhost:8080/login`
- Registro: `http://localhost:8080/register`
- H2 Console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:aviamentosdb`, user: `sa`).

## Tecnologias
- Spring Boot (Web, Security, Thymeleaf)
- Spring Data JPA (Hibernate)
- H2 (dev)
- Bean Validation

## Próximas etapas
- **Produto** e **Movimentação** (estoque), busca e ordenação; alertas de estoque mínimo; testes.
