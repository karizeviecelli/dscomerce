package com.aviamentos.repository;

/*
 * Camada de repositório (DAO) usando Spring Data JPA.
 * - JpaRepository fornece CRUD pronto.
 * - Métodos query derivation (findByEmail / existsByEmail) são implementados automaticamente.
 */
import com.aviamentos.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmail(String email);
    boolean existsByEmail(String email);
}
