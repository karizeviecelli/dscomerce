package com.aviamentos.controller;

/*
 * Camada de controladores Web (Spring MVC).
 * Responsável por:
 *  - Exibir telas de login/registro.
 *  - Processar POST de cadastro.
 *  - Encaminhar para a view (Thymeleaf) com o modelo adequado.
 */
import com.aviamentos.dto.RegistroUsuarioDTO;
import com.aviamentos.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    private final UsuarioService usuarioService;

    public AuthController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // GET /login: exibe o formulário de autenticação (Spring Security processa o POST /login automaticamente).
    @GetMapping("/login")
    public String login() {
        return "auth/login";
    }

    // GET /register: exibe o formulário de registro.
    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("form", new RegistroUsuarioDTO());
        return "auth/register";
    }

    // POST /register: processa o cadastro de um novo usuário.
    @PostMapping("/register")
    public String doRegister(@ModelAttribute("form") @Valid RegistroUsuarioDTO form,
                             Model model) {
        try {
            usuarioService.registrar(form);
            // Redireciona para login com um parâmetro que ativa o alerta de sucesso na view.
            return "redirect:/login?registered=true";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "auth/register";
        }
    }

    // GET /home: área autenticada após login.
    @GetMapping("/home")
    public String home() {
        return "home";
    }
}
