package com.aviamentos.config;

/*
 * Configuração de segurança usando Spring Security 6.
 * Conceitos principais:
 *  - SecurityFilterChain: cadeia de filtros que interceptam requisições HTTP (autenticação/autorização).
 *  - UserDetailsService: carrega o usuário (credenciais/roles) a partir do banco.
 *  - PasswordEncoder: responsável por aplicar hash seguro (BCrypt) nas senhas.
 *  - Form Login: autenticação por formulário tradicional, com páginas de login/logout personalizadas.
 */
import com.aviamentos.domain.Usuario;
import com.aviamentos.repository.UsuarioRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    /*
     * UserDetailsService:
     *  - Interface que o Spring Security usa para buscar um usuário pelo "username" (aqui, o e-mail).
     *  - Convertendo a entidade Usuario (JPA) para um UserDetails do Spring Security.
     */
    @Bean
    public UserDetailsService userDetailsService(UsuarioRepository repo) {
        return username -> {
            Usuario u = repo.findByEmail(username)
                    .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));
            // Builder do Spring Security para criar um UserDetails com roles.
            return User.withUsername(u.getEmail())
                    .password(u.getSenhaHash())
                    .roles(u.getRole().replace("ROLE_", "")) // converte "ROLE_USER" -> "USER"
                    .build();
        };
    }

    /*
     * PasswordEncoder:
     *  - BCrypt: algoritmo de hash com salt embutido, adequado para senhas de usuários.
     *  - Evitar guardar senhas em texto plano (boa prática de segurança).
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /*
     * SecurityFilterChain:
     *  - Define quais rotas são públicas e quais exigem autenticação.
     *  - Configura a página de login (GET /login) e tratamento de sucesso/erro.
     *  - Configura logout.
     *  - Libera o H2-console em desenvolvimento (frameOptions sameOrigin).
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(Customizer.withDefaults())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/css/**","/js/**","/images/**","/register","/login","/h2-console/**").permitAll()
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login").permitAll()
                .defaultSuccessUrl("/home", true)
                .failureUrl("/login?error=true")
            )
            .logout(l -> l.logoutUrl("/logout").logoutSuccessUrl("/login?logout=true"));

        // Necessário para o H2-console funcionar (usa frames)
        http.headers(h -> h.frameOptions(f -> f.sameOrigin()));
        return http.build();
    }
}
