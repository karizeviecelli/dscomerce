package com.aviamentos.service;

/*
 * Camada de serviço: regras de negócio e orquestração entre repositórios.
 * - Aplica validações de unicidade de e-mail.
 * - Aplica hash seguro na senha (BCrypt).
 * - Mantém a aplicação coesa e testável.
 */
import com.aviamentos.domain.Usuario;
import com.aviamentos.dto.RegistroUsuarioDTO;
import com.aviamentos.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UsuarioService {

    private final UsuarioRepository repo;
    private final PasswordEncoder encoder;

    public UsuarioService(UsuarioRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    /*
     * Registrar um novo usuário:
     *  - Verifica se o e-mail já existe.
     *  - Gera o hash da senha com BCrypt.
     *  - Salva a entidade no banco H2 via JPA.
     *  - @Transactional garante atomicidade (importante em operações de escrita).
     */
    @Transactional
    public Usuario registrar(RegistroUsuarioDTO dto) {
        if (repo.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("E-mail já cadastrado.");
        }
        Usuario u = new Usuario();
        u.setNome(dto.getNome());
        u.setEmail(dto.getEmail());
        u.setSenhaHash(encoder.encode(dto.getSenha()));
        u.setRole("ROLE_USER");
        return repo.save(u);
    }
}
