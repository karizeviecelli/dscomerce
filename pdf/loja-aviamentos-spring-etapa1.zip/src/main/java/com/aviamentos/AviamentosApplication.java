package com.aviamentos;

/*
 * Classe principal da aplicação Spring Boot.
 * - Responsável por iniciar o contexto do Spring (IoC container) e o servidor embutido (Tomcat por padrão).
 * - O @SpringBootApplication habilita:
 *   - @Configuration (configuração baseada em Java);
 *   - @EnableAutoConfiguration (autoconfiguração do Spring Boot);
 *   - @ComponentScan (varredura de componentes no pacote com.aviamentos e subpacotes).
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AviamentosApplication {

    public static void main(String[] args) {
        // Método que inicializa toda a aplicação Spring.
        SpringApplication.run(AviamentosApplication.class, args);
    }
}
