package com.aviamentos.dto;

/*
 * DTO (Data Transfer Object) para o formulário de registro.
 * Motivações para usar DTO:
 *  - Evitar expor a entidade diretamente nas camadas de apresentação.
 *  - Aplicar validações específicas do caso de uso (Bean Validation).
 *  - Facilitar evolução do formulário sem afetar a entidade base.
 */
import jakarta.validation.constraints.*;

public class RegistroUsuarioDTO {

    @NotBlank
    @Size(min = 2, max = 100)
    private String nome;

    @NotBlank
    @Email
    @Size(max = 120)
    private String email;

    @NotBlank
    @Size(min = 6, max = 72) // limite BCrypt
    private String senha;

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
}
