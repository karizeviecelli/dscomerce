package com.aviamentos.domain;

/*
 * Entidade JPA que representa um usuário do sistema.
 * Conceitos:
 *  - @Entity: classe mapeada para uma tabela no banco.
 *  - @Table: permite customizar o nome e restrições (unique em email).
 *  - Bean Validation: validação de campos na camada de domínio (consistência).
 *  - Regra de segurança: "senhaHash" guarda o hash BCrypt da senha.
 */
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "usuarios", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto incremento (H2/Hibernate)
    private Long id;

    @NotBlank
    @Size(min = 2, max = 100)
    private String nome;

    @NotBlank
    @Email
    @Size(max = 120)
    private String email;

    // Por segurança, nunca guardamos a senha em claro; apenas o hash.
    @Column(name = "senha_hash", nullable = false)
    private String senhaHash;

    // Role (perfil) com o prefixo "ROLE_" por convenção do Spring Security.
    @NotBlank
    private String role = "ROLE_USER";

    // Registro de auditoria simples (momento do cadastro).
    private LocalDateTime criadoEm = LocalDateTime.now();

    // Getters e Setters (poderiam ser gerados pelo Lombok: @Getter/@Setter)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenhaHash() { return senhaHash; }
    public void setSenhaHash(String senhaHash) { this.senhaHash = senhaHash; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public LocalDateTime getCriadoEm() { return criadoEm; }
    public void setCriadoEm(LocalDateTime criadoEm) { this.criadoEm = criadoEm; }
}
