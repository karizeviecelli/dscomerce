package com.dev.dscomerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DscomerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
