package com.dev.dscomerce.controllers.handlers;

public class CustomException {

}
